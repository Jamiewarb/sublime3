
/* @DIALOG POPUP
 * Dialog popup style and progressbar
========================================================================= */

  {
    "class": "progress_gauge_control",
    "layer0.tint": [128, 203, 196],
    "layer0.opacity": 1.0,
    "content_margin": [0, 6]
  },

  {
    "class": "dialog",
    "layer0.tint": [33, 33, 33],
    "layer0.opacity": 1.0
  },

  {
    "class": "progress_bar_control",
    "layer0.tint": [33, 33, 33],
    "layer0.opacity": 1.0,
  },
