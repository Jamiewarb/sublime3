
/* @TOOLTIP
 * Tooltip setting and behavioring
========================================================================= */

  {
    "class": "tool_tip_control",
    "layer0.tint": [128, 203, 196],
    "layer0.inner_margin": [0, 0],
    "layer0.opacity": 1.0,
    "content_margin": [16, 8]
  },

  {
    "class": "tool_tip_label_control",
    "color": [0, 0, 0, 150]
  },