
/* @EMPTY WINDOW
 * Style for empty (no tabs) window
========================================================================= */

  {
    "class": "sheet_container_control",
    "layer0.tint": [38, 50, 56],
    "layer0.opacity": 1.0
  },

/* @GRID LAYOUT
 * Grid style
========================================================================= */

  {
    "class": "grid_layout_control",
    "border_size": 1,
    "border_color": [34, 45, 51]
  },