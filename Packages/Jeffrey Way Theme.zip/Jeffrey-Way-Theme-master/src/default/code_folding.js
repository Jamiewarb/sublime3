
/* @ CODE FOLDING
 * Folding arrow setting and behavioring
========================================================================= */

  {
    "class": "fold_button_control",
    "layer0.texture": "Material Theme/assets/commons/fold_right.png",
    "layer0.opacity": 1.0,
    "layer0.inner_margin": 0,
    "layer1.texture": "Material Theme/assets/commons/fold_right--hover.png",
    "layer1.opacity": 0.0,
    "layer1.inner_margin": 0,
    "content_margin": [9, 7, 8, 6]
  },

  {
    "class": "fold_button_control",
    "attributes": ["hover"],
    "layer0.opacity": 0.0,
    "layer1.opacity": 1.0
  },

  {
    "class": "fold_button_control",
    "attributes": ["expanded"],
    "layer0.texture": "Material Theme/assets/default/fold_down.png",
    "layer1.texture": "Material Theme/assets/commons/fold_down--hover.png"
  },
