
/* @ STATUS BAR
 * Status bar settings and behavioring
========================================================================= */

  // All labels

  {
    "class": "label_control",
    "color": [176, 190, 197],
    "shadow_color": [24, 24, 24, 0],
    "shadow_offset": [0, 0],
    "font.bold": true
  },

    // Status bar labels

   {
      "class": "label_control",
      "parents": [{"class": "status_bar"}],
      "color": [120, 144, 156],
      "font.bold": false
  },

    // Text field labels

  {
    "class": "status_bar",

    // Layer 0 base
    "layer0.tint": [38, 50, 56],
    "layer0.opacity": 1.0,
    "layer0.inner_margin": [2, 2],

    // Visible tint layer
    "layer1.tint": [38, 50, 56],
    "layer1.opacity": 1.0,
    "layer1.inner_margin": [2, 2],

    "content_margin": [0, 0]
  },

  {
    "class": "status_container",
    "content_margin": [24, 12, 24, 12],
  },

  {
    "class": "status_button",
    "layer0.tint": [38, 50, 56],
    "layer0.opacity": 1.0,
    "layer0.draw_center": false,
    "layer0.inner_margin": [1, 0, 0, 0],
    "content_margin": [10, 2, 10, 3],
    "min_size": [75, 0]
  },

  {
    "class": "status_button",
    "layer0.tint": [38, 50, 56],
    "layer0.opacity": 1.0,
    "layer0.draw_center": false,
    "layer0.inner_margin": [1, 0, 0, 0],
    "content_margin": [10, 2, 10, 3],
    "min_size": [75, 0],
  },

  // panel switcher
  {
    "class": "panel_button_control",
    "layer0.texture": "Material Theme/assets/default/overflow_menu.png",
    "layer0.opacity": 1.0,
    "content_margin": [10, 10]
  },

  {
    "class": "panel_button_control",
    "attributes": ["hover"],
    "layer0.texture": "Material Theme/assets/commons/overflow_menu--hover.png",
  },